package com.example.saga;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements MyAdapter.OnSongListener {

    private static final String TAG = "MainActivity";
    ImageView mic;
    public static final int REQUEST_CODE = 100;
    private RecyclerView recyclerview;
    int size;
    static ArrayList<listofsongs> songlist;
    MyAdapter myAdapter;
    static MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mic = findViewById(R.id.mic);
        recyclerview = findViewById(R.id.recyclerview);
        songlist = new ArrayList<>();
        size = songlist.size();

        myAdapter = new MyAdapter(this,songlist, this);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        recyclerview.setAdapter(myAdapter);

        songlist.add(new listofsongs(R.raw.you_need_to_calm_down, "You Need To Calm Down", "Taylor Swift", R.drawable.you_need_to_calm_down_album_art));
        songlist.add(new listofsongs(R.raw.what_makes_you_beautiful, "What Makes You Beautiful", "One Direction", R.drawable.what_makes_you_beautiful_album_art));

        mic.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                //intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                try {
                    startActivityForResult(intent, REQUEST_CODE);
                } catch (ActivityNotFoundException a) {

                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode){
            case REQUEST_CODE:
                if(resultCode == RESULT_OK && data!=null) {
                    ArrayList<String> command = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    String myCommand = command.get(0);
                    String playCommand = "";
                    String pauseCommand = "";
                    String songForPlay = "";

                    playCommand = myCommand.substring(0, 4);
                    pauseCommand = myCommand.substring(0, 6);

                    if (playCommand.equalsIgnoreCase("play")) {
                        songForPlay = myCommand.substring(5);

                        int i;
                        for(i = 0; i <size;i++)
                        {
                            if(songForPlay.equalsIgnoreCase(songlist.get(i).nameofsongs)){
                                onSongClick(i);
                            }
                        }
                    }

                    if(pauseCommand.equalsIgnoreCase("pause")){
                        mediaPlayer.stop();
                    }
                }break;
        }
    }

    public void onSongClick(int position) {
        Log.d( TAG, "playing this song");
        mediaPlayer = new MediaPlayer();
        songlist.get(position);
        Intent intent = new Intent(MainActivity.this, PlayingActivity.class);
        intent.putExtra("SONGS", songlist.get(position));
        intent.putExtra("position",position);
        startActivity(intent);
        if(mediaPlayer!=null) {
            mediaPlayer.reset();
        }
    }
}
