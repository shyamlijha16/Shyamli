package com.example.saga;

import android.os.Parcel;
import android.os.Parcelable;

public class listofsongs implements Parcelable {

    String nameofsongs;
    String nameofartists;
    int data;
    int albumart;

    public listofsongs(int data, String nameofsongs, String nameofartists, int albumart){
        this.nameofsongs = nameofsongs;
        this.nameofartists = nameofartists;
        this.data = data;
        this.albumart = albumart;
    }

    protected listofsongs(Parcel in) {
        nameofsongs = in.readString();
        nameofartists = in.readString();
        data = in.readInt();
        albumart = in.readInt();
    }

    public static final Creator<listofsongs> CREATOR = new Creator<listofsongs>() {
        @Override
        public listofsongs createFromParcel(Parcel in) {
            return new listofsongs(in);
        }

        @Override
        public listofsongs[] newArray(int size) {
            return new listofsongs[size];
        }
    };

    public String getNameofsongs() {
        return nameofsongs;
    }

    public String getNameofartists() {
        return nameofartists;
    }

    public int getData() {
        return data;
    }

    public int getAlbumart() {
        return albumart;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(nameofsongs);
        parcel.writeString(nameofartists);
        parcel.writeInt(data);
        parcel.writeInt(albumart);
    }
}
