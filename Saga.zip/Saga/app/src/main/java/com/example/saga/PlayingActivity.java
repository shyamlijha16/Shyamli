package com.example.saga;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import static com.example.saga.MainActivity.mediaPlayer;
import static com.example.saga.MainActivity.songlist;

public class PlayingActivity extends AppCompatActivity {

    ImageView play_previous;
    ImageView play_next;
    ImageView play_pause;
    ImageView album_art;
    TextView initial_position;
    TextView final_position;
    TextView title_of_song;
    int position;
    int size;
    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playing);

        play_previous = findViewById(R.id.play_previous);
        play_next = findViewById(R.id.play_next);
        play_pause = findViewById(R.id.play_pause);
        album_art = findViewById(R.id.album_art);
        initial_position = findViewById(R.id.initial_position);
        final_position = findViewById(R.id.final_position);
        title_of_song = findViewById(R.id.title_of_song);
        initial_position = findViewById(R.id.initial_position);
        final_position = findViewById(R.id.final_position);
        seekBar = findViewById(R.id.seekBar);

        position = getIntent().getIntExtra("position", 0);
        size = songlist.size();

        mediaPlayer = MediaPlayer.create(this, songlist.get(position).data);
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mediaPlayer.start();

        title_of_song.setText(songlist.get(position).nameofsongs);
        album_art.setImageResource(songlist.get(position).albumart);

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {

                seekBar.setMax(mediaPlayer.getDuration());
                String total_time = createTimerLabel(mediaPlayer.getDuration());
                final_position.setText(total_time);
                play_pause.setImageResource(R.drawable.pause);
                mediaPlayer.start();
            }
        });

        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            play_pause.setImageResource(R.drawable.play);
        } else {
            play_pause.setImageResource(R.drawable.pause);
            mediaPlayer.start();
        }

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                if (position < size - 1) {
                    position++;
                } else {
                    position = 0;
                }
                mediaPlayer = MediaPlayer.create(getApplicationContext(), songlist.get(position).data);
                title_of_song.setText(songlist.get(position).nameofsongs);
                album_art.setImageResource(songlist.get(position).albumart);
                mediaPlayer.start();
            }
        });

        play_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (position < size - 1) {
                    position++;
                } else {
                    position = 0;
                }
                mediaPlayer = MediaPlayer.create(getApplicationContext(), songlist.get(position).data);
                title_of_song.setText(songlist.get(position).nameofsongs);
                album_art.setImageResource(songlist.get(position).albumart);
                mediaPlayer.start();
            }
        });

        play_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (position <= 0) {
                    position = size - 1;
                } else {
                    position--;
                }
                mediaPlayer = MediaPlayer.create(getApplicationContext(), songlist.get(position).data);
                title_of_song.setText(songlist.get(position).nameofsongs);
                album_art.setImageResource(songlist.get(position).albumart);
                mediaPlayer.start();
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seek, int progress, boolean fromUser) {
                if(fromUser)
                {
                    mediaPlayer.seekTo(progress);
                    seekBar.setProgress(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(mediaPlayer!=null){
                    try{
                        if(mediaPlayer.isPlaying()){
                            Message message = new Message();
                            message.what = mediaPlayer.getCurrentPosition();
                            handler.sendMessage(message);
                            Thread.sleep(1000);
                        }
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    @SuppressLint("HandlerLeak")
    private  Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg){
            initial_position.setText(createTimerLabel(msg.what));
            seekBar.setProgress(msg.what);
        }
    };

    public String createTimerLabel(int duration){
        String timerLabel = "";
        int min = duration/1000/60;
        int sec = duration/1000%60;

        timerLabel += min + ":";

        if(sec<10) timerLabel+= "0";
        timerLabel += sec;

        return timerLabel;
    }
}