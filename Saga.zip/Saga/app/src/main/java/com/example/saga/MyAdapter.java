package com.example.saga;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    Context context;
    ArrayList<listofsongs> songlist;
    private OnSongListener onSongListener2;

    public MyAdapter(Context context, ArrayList<listofsongs> songlist, OnSongListener onSongListener2){
        this.context = context;
        this.songlist = songlist;
        this.onSongListener2 = onSongListener2;
    }
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View row = inflater.inflate(R.layout.row, parent, false);
        Item item = new Item(row, onSongListener2);
        return item;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((Item)holder).songs.setText(songlist.get(position).nameofsongs);
        ((Item)holder).albums.setText(songlist.get(position).nameofartists);
    }

    @Override
    public int getItemCount() {
        return songlist.size();
    }

    public class Item extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView songs;
        TextView albums;
        OnSongListener onSongListener;

        public Item(View itemView, OnSongListener onSongListener){
            super(itemView);
            songs = (TextView) itemView.findViewById(R.id.songs);
            albums = (TextView) itemView.findViewById(R.id.albums);
            this.onSongListener = onSongListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onSongListener.onSongClick(getAdapterPosition());
        }
    }
    public interface OnSongListener{
        void onSongClick(int position);
    }
}
