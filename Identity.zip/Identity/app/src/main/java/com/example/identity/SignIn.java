package com.example.identity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignIn extends AppCompatActivity {

    EditText usernameEntry;
    EditText passwordEntry;
    EditText confirmPasswordEntry;
    Button signInIdButton;
    MyHelper secondHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        usernameEntry = findViewById(R.id.usernameEntry);
        passwordEntry = findViewById(R.id.passwordEntry);
        confirmPasswordEntry = findViewById(R.id.confirmPasswordEntry);
        signInIdButton = findViewById(R.id.signInIdButton);
        secondHelper = new MyHelper(this);

        usernameEntry.requestFocus();
        passwordEntry.requestFocus();
        confirmPasswordEntry.requestFocus();

        signInIdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = usernameEntry.getText().toString().trim();
                String pwd = passwordEntry.getText().toString().trim();
                String cnf_pwd = confirmPasswordEntry.getText().toString().trim();

                if((pwd.length()<8)&&(cnf_pwd.length()<8))
                {
                    Toast.makeText(SignIn.this,"input a strong password of 8 characters", Toast.LENGTH_SHORT).show();
                }

                if(pwd.equals(cnf_pwd)) {
                    boolean val = secondHelper.userData(user,pwd);
                    if(val == true) {
                        Toast.makeText(SignIn.this, "You have registered successfully", Toast.LENGTH_SHORT).show();
                        Intent i = new Intent(SignIn.this, MainActivity.class);
                        startActivity(i);
                    }else{
                        Toast.makeText(SignIn.this, "Registration Error", Toast.LENGTH_SHORT).show();
                    }
                } else{
                    Toast.makeText(SignIn.this,"Password is not matching", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
