package com.example.identity;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ShowDetails extends AppCompatActivity {

    MyHelper helper;
    TextView details;
    ListView listview;
    private ArrayList detailsOfMembers = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_details);

        listview = findViewById(R.id.listview);
        details = findViewById(R.id.details);
        helper = new MyHelper(this);
        Cursor cursor = helper.showData();

        if (cursor.getCount() == 0) {
            Toast.makeText(ShowDetails.this, "NO DATA", Toast.LENGTH_SHORT).show();
        } else /*if(cursor.getCount()!=0)*/ {
            while (cursor.moveToNext()) {
                StringBuilder builder = new StringBuilder();
                String firstname = cursor.getString(1);
                String lastname = cursor.getString(2);
                Integer dateofbirth = cursor.getInt(3);
                String fathername = cursor.getString(4);
                String mothername = cursor.getString(5);
                String currentAddress = cursor.getString(6);
                String permanentAddress = cursor.getString(7);
                Integer firstPhnNo = cursor.getInt(8);
                Integer secondPhnNo = cursor.getInt(9);
                Integer adhaarNo = cursor.getInt(10);
                String pancardNo = cursor.getString(11);
                String bankName = cursor.getString(12);
                Integer bankAcc = cursor.getInt(13);
                String firm = cursor.getString(14);
                String relation = cursor.getString(15);

                builder.append("FIRST_NAME : " + firstname + "\n" +
                               "LAST_NAME : " + lastname + "\n" +
                               "DATE_OF_BIRTHDAY : " + dateofbirth + "\n" +
                               "FATHER_NAME : " + fathername + "\n" +
                               "MOTHER_NAME : " + mothername + "\n" +
                               "CURRENT_ADDRESS : " + currentAddress + "\n" +
                               "PERMANENT_ADDRESS : " + permanentAddress + "\n" +
                               "FIRST_PHONE.NO : " + firstPhnNo + "\n" +
                               "SECOND_PHN.NO : " + secondPhnNo + "\n" +
                               "ADHAAR_NUMBER : " + adhaarNo + "\n" +
                               "PANCARD_NUMBER : " + pancardNo + "\n" +
                               "BANK_NAME : " + bankName + "\n" +
                               "BANK_ACCOUNT.NO : " + bankAcc + "\n" +
                               "FIRM : " + firm + "\n" +
                               "RELATION : " + relation);

                detailsOfMembers.add(builder.toString());

                Adapter adapt = new Adapter(ShowDetails.this, detailsOfMembers);
                listview.setAdapter(adapt);
                cursor.close();

            }
        }
    }
}
