package com.example.identity;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyHelper extends SQLiteOpenHelper {

    private static final String dbname = "mydb";
    private static final int version = 2;

    public MyHelper(Context context){
        super(context, dbname, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "CREATE TABLE PERSONAL_DETAILS(_Id INTEGER PRIMARY KEY AUTOINCREMENT, FIRST_NAME TEXT, LAST_NAME TEXT, DATE_OF_BIRTH INTEGER, FATHER_NAME TEXT, MOTHER_NAME TEXT, CURRENT_ADDRESS TEXT, PERMANENT_ADDRESS TEXT, FIRST_PHNNO INTEGER, SECOND_PHNNO INTEGER, ADHAAR_NO INTEGER, PANCARD_NUMBER TEXT, BANK_NAME TEXT, BANK_ACC INTEGER, FIRM TEXT, RELATION TEXT)";
        String secondSql = "CREATE TABLE USER_DETAILS(_Id INTEGER PRIMARY KEY AUTOINCREMENT, USERNAME TEXT, PASSWORD TEXT)";
        sqLiteDatabase.execSQL(sql);
        sqLiteDatabase.execSQL(secondSql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public boolean addData(String firstname, String lastname, Integer dateofbirth, String fathername, String mothername, String currentAddress, String permanentAddress, Integer firstPhnNo, Integer secondPhnNo, Integer adhaarNo, String pancardNo, String bankName, Integer bankAcc, String firm, String relation){
        ContentValues contentValues = new ContentValues();
        SQLiteDatabase database = this.getWritableDatabase();

        contentValues.put("FIRST_NAME",firstname);
        contentValues.put("LAST_NAME",lastname);
        contentValues.put("DATE_OF_BIRTH",dateofbirth);
        contentValues.put("FATHER_NAME",fathername);
        contentValues.put("MOTHER_NAME",mothername);
        contentValues.put("CURRENT_ADDRESS",currentAddress);
        contentValues.put("PERMANENT_ADDRESS",permanentAddress);
        contentValues.put("FIRST_PHNNO",firstPhnNo);
        contentValues.put("SECOND_PHNNO",secondPhnNo);
        contentValues.put("ADHAAR_NO",adhaarNo);
        contentValues.put("PANCARD_NUMBER",pancardNo);
        contentValues.put("BANK_NAME",bankName);
        contentValues.put("BANK_ACC",bankAcc);
        contentValues.put("FIRM",firm);
        contentValues.put("RELATION",relation);

        long result = database.insert("PERSONAL_DETAILS", null, contentValues);
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor showData(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM PERSONAL_DETAILS", null);
        return cursor;
    }

    public boolean userData(String usernameEntry, String passwordEntry){
        SQLiteDatabase secondDatabase = this.getWritableDatabase();
        ContentValues secondContentValues = new ContentValues();

        secondContentValues.put("USERNAME",usernameEntry);
        secondContentValues.put("PASSWORD",passwordEntry);

        long secondResult = secondDatabase.insert("USER_DETAILS", null, secondContentValues);
        if(secondResult == -1){
            return false;
        }else{
            return true;
        }
    }

    public boolean checkUser(String username,String password){
        SQLiteDatabase secondDatabase = this.getReadableDatabase();
        Cursor secondCursor = secondDatabase.rawQuery("SELECT * FROM USER_DETAILS", null);
        int count = secondCursor.getCount();

        if(count>0){
            return true;
        }else{
            return false;
        }
    }
}
