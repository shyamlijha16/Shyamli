package com.example.identity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DataEntry extends AppCompatActivity {

    ScrollView scrollview;
    MyHelper helper;
    EditText firstname;
    EditText lastname;
    EditText dateofbirth;
    EditText fathername;
    EditText mothername;
    EditText currentAddress;
    EditText permanentAddress;
    EditText firstPhoNo;
    EditText secondPhoNo;
    EditText adhaarNo;
    EditText pancardNo;
    EditText bankName;
    EditText bankAcc;
    EditText firm;
    EditText relation;
    Button submit;
    Button showDetails;
    final Calendar myCalendar = Calendar.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_entry);

        scrollview = findViewById(R.id.scrollview);
        firstname = findViewById(R.id.firstname);
        lastname = findViewById(R.id.lastname);
        dateofbirth = findViewById(R.id.dateofbirth);
        fathername = findViewById(R.id.fathername);
        mothername = findViewById(R.id.mothername);
        currentAddress = findViewById(R.id.currentAddress);
        permanentAddress = findViewById(R.id.permanentAddress);
        firstPhoNo = findViewById(R.id.firstPhnNo);
        secondPhoNo = findViewById(R.id.secondPhnNo);
        adhaarNo = findViewById(R.id.adhaarNo);
        pancardNo = findViewById(R.id.pancardNo);
        bankName = findViewById(R.id.bankName);
        bankAcc = findViewById(R.id.bankAcc);
        firm = findViewById(R.id.firm);
        relation = findViewById(R.id.relation);
        submit = findViewById(R.id.submit);
        showDetails = findViewById(R.id.showDetails);


        helper = new MyHelper(this);

        onClick();


    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        dateofbirth.setText(sdf.format(myCalendar.getTime()));
    }

    public void insertData(String firstname, String lastname, Integer dateofbirth, String fathername, String mothername, String currentAddress, String permanentAddress, Integer firstPhnNo, Integer secondPhnNo, Integer adhaarNo,String pancardNo, String bankName, Integer bankAcc, String firm, String relation){
        boolean data = helper.addData(firstname, lastname, dateofbirth, fathername, mothername, currentAddress, permanentAddress, firstPhnNo, secondPhnNo, adhaarNo, pancardNo, bankName, bankAcc, firm, relation);

        if(data == true)
        {
            toastMessage("Data successfully inserted");
        }
        else
        {
            toastMessage("Something went wrong");
        }
    }

    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void onClick(){

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dateOfMonth) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dateOfMonth);
                updateLabel();
            }
        };

        dateofbirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new DatePickerDialog(DataEntry.this, date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String firstName = firstname.getText().toString();
                String lastName = lastname.getText().toString();
                Integer dateOfBirth = dateofbirth.getInputType();
                String fatherName = fathername.getText().toString();
                String motherName = mothername.getText().toString();
                String currentaddress = currentAddress.getText().toString();
                String permanentaddress = permanentAddress.getText().toString();
                Integer firstphnno = firstPhoNo.getInputType();
                Integer secondphnno = secondPhoNo.getInputType();
                Integer adhaarno = adhaarNo.getInputType();
                String pancardno = pancardNo.getText().toString();
                String bankname = bankName.getText().toString();
                Integer bankacc = bankAcc.getInputType();
                String firm2 = firm.getText().toString();
                String relation2 = relation.getText().toString();

                if(firstPhoNo.length()<10){
                    toastMessage("enter a valid phone no.");
                }

                if(secondPhoNo.length()<10){
                    toastMessage("enter a valid phone no.");
                }

                if(adhaarNo.length()<12){
                    toastMessage("enter a valid adhaar no.");
                }

                if(pancardNo.length()<10){
                    toastMessage("enter a valid phone no.");
                }

                if(bankAcc.length()<12){
                    toastMessage("enter a valid phone no.");
                }

                if((firstname.length()!=0)&&(lastname.length()!=0)&&(dateofbirth.length()!=0)&&(fathername.length()!=0)&&(mothername.length()!=0)&&(currentAddress.length()!=0)&&(permanentAddress.length()!=0)&&(firstPhoNo.length()==10)&&(secondPhoNo.length()==10)&&(adhaarNo.length()==12)&&(pancardNo.length()==10)&&(bankName.length()!=0)&&(bankAcc.length()==12)&&(firm.length()!=0)&&(relation.length()!=0)){
                    insertData(firstName, lastName, dateOfBirth, fatherName, motherName, currentaddress, permanentaddress, firstphnno, secondphnno, adhaarno, pancardno, bankname, bankacc, firm2, relation2);
                    firstname.setText("");
                    lastname.setText("");
                    dateofbirth.setText("");
                    fathername.setText("");
                    mothername.setText("");
                    currentAddress.setText("");
                    permanentAddress.setText("");
                    firstPhoNo.setText("");
                    secondPhoNo.setText("");
                    adhaarNo.setText("");
                    pancardNo.setText("");
                    bankName.setText("");
                    bankAcc.setText("");
                    firm.setText("");
                    relation.setText("");

                    firstname.requestFocus();
                    lastname.requestFocus();
                    dateofbirth.requestFocus();
                    fathername.requestFocus();
                    mothername.requestFocus();
                    currentAddress.requestFocus();
                    permanentAddress.requestFocus();
                    firstPhoNo.requestFocus();
                    secondPhoNo.requestFocus();
                    adhaarNo.requestFocus();
                    pancardNo.requestFocus();
                    bankName.requestFocus();
                    bankAcc.requestFocus();
                    firm.requestFocus();
                    relation.requestFocus();
                }
                else{
                    toastMessage("You must put something in the text field");
                }
            }
        });

        showDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(DataEntry.this,ShowDetails.class);
                startActivity(i);
            }
        });

    }
}
