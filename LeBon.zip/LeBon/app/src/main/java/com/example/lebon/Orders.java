package com.example.lebon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import static com.example.lebon.Buynow.allitems;
import static com.example.lebon.MainActivity.addtocart;
import static com.example.lebon.MainActivity.allproducts;


public class Orders extends AppCompatActivity {

    ListView listview4;
    public static ArrayList<CakeList> orderitems;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        orderitems = new ArrayList<>();

        listview4 = findViewById(R.id.listview4);
        AdapterBuynow adapt2 = new AdapterBuynow(this,R.layout.row3,allitems);
        listview4.setAdapter(adapt2);

    }
}
