package com.example.lebon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Contact extends AppCompatActivity {

    ImageView mcall;
    ImageView mmail;
    TextView mcontact2;
    TextView mmailid;
    TextView mpno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        ImageView mcall =(ImageView) findViewById(R.id.call);
        ImageView mmail = findViewById(R.id.mail);
        TextView mcontact2 = findViewById(R.id.contact2);
        TextView mmailid = findViewById(R.id.mailid);
        TextView mpno = findViewById(R.id.pno);

        mpno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri u = Uri.parse("tel:+918235221231");
                Intent i = new Intent(Intent.ACTION_DIAL, u);
                startActivity(i);
            }
        });

        mcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri u = Uri.parse("tel:+918235221231");
                Intent i = new Intent(Intent.ACTION_DIAL, u);
                startActivity(i);
            }
        });

        mmailid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                startActivity(i);
            }
        });

        mmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.setData(Uri.parse("Mail to:"));
                i.putExtra(Intent.EXTRA_EMAIL, "shyamlijha1997@gmail.com");
                startActivity(i);
            }
        });
    }
}
