package com.example.lebon;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;


public class AdapterAddtofavourites extends ArrayAdapter<CakeList> {

    Context ncontext;
    int resource2;
    ArrayList<CakeList> mobjects;

    public AdapterAddtofavourites(@NonNull Context ncontext, int resource2, ArrayList<CakeList> mobjects) {
        super(ncontext, resource2, mobjects);
        this.ncontext = ncontext;
        this.resource2 = resource2;
        this.mobjects = mobjects;
    }
    @NonNull
    @Override
    public View getView(final int position, @NonNull View convertView, @NonNull ViewGroup parent){
        LayoutInflater ninflater = LayoutInflater.from(ncontext);

        View nview = ninflater.inflate(resource2,null);
        TextView nameofcakes2 = nview.findViewById(R.id.nameofproducts2);
        TextView amountofcakes2 = nview.findViewById(R.id.amountofproducts2);
        ImageView imagebutton2 = nview.findViewById(R.id.imagebutton2);

        final CakeList cakelist = mobjects.get(position);

        nameofcakes2.setText(cakelist.getNameofproducts());
        amountofcakes2.setText(cakelist.getAmount()+"");
        imagebutton2.setImageDrawable(ncontext.getResources().getDrawable(cakelist.getImage()));

        final Button buynow2 = nview.findViewById(R.id.buynow2);
        Button delete = nview.findViewById(R.id.delete);

        buynow2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View mv) {
                Intent i4 = new Intent(getContext(),Buynow.class);
                i4.putExtra("index",position);
                i4.putExtra("Buy all",-1);
                getContext().startActivity(i4);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View mv) {
                mobjects.remove(position);
                notifyDataSetChanged();
                toastMessage("ITEM DELETED");
            }
        });

        return nview;
    }
    private void toastMessage(String message) {
        Toast.makeText(ncontext, message, Toast.LENGTH_SHORT).show();
    }
}
