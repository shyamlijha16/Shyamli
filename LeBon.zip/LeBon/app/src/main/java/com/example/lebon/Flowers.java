package com.example.lebon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class Flowers extends AppCompatActivity {

    Toolbar mtoolbar;
    List<CakeList> objects;
    ListView mlistview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flowers);

        objects = new ArrayList<>();
        objects.add(new CakeList(R.drawable.amaryllis, "BOUQUET OF AMARYLLIS", 900));
        objects.add(new CakeList(R.drawable.lilies, "BOUQUET OF LILIES", 700));
        objects.add(new CakeList(R.drawable.roses, "BOUQUET OF ROSES", 500));

        mlistview = findViewById(R.id.listview);
        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (view.getId()){
                    case R.id.buynow:
                        Intent i3 = new Intent(Flowers.this,Buynow.class);
                        i3.putExtra("index", i);
                        i3.putExtra("buy all",-1);
                        startActivity(i3);
                        break;
                }
            }
        });

        AdapterCakes adapter = new AdapterCakes(this, R.layout.row, objects);
        mlistview.setAdapter(adapter);

        Toolbar mtoolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("FLOWERS");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.orders){
            Intent i2 = new Intent(Flowers.this,Orders.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.favorites){
            Intent i2 = new Intent(Flowers.this,MyFavourites.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.contact){
            Intent i2 = new Intent(Flowers.this,Contact.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.feedback){
            Intent i2 = new Intent(Flowers.this,Feedback.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.basket){
            Intent i2 = new Intent(Flowers.this,Addtocart.class);
            startActivity(i2);
        }
        return super.onOptionsItemSelected(item);
    }
    public void changeactivity(){
        Intent i3 = new Intent(Flowers.this,Orders.class);
        startActivity(i3);
    }
}
