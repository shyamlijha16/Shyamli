package com.example.lebon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Feedback extends AppCompatActivity {

    public static final String tag = "FEEDBACKS";

    DatabaseHelper mDatabaseHelper;
    EditText medittext;
    TextView mfeedback2;
    Button msubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        TextView mfeedback2 = findViewById(R.id.feedback2);
        final EditText medittext = findViewById(R.id.edittext);
        Button msubmit = findViewById(R.id.submit);
        mDatabaseHelper = new DatabaseHelper(this);

        msubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newEntry = medittext.getText().toString();
                if(medittext.length()!=0)
                {
                    AddData(newEntry);
                    medittext.setText("");
                    medittext.requestFocus();
                }
                else
                {
                    toastMessage("You must put something in the text field");
                }
            }
        });
    }

    public void AddData(String newEntry) {
        boolean insertData = mDatabaseHelper.addData(newEntry);

        if(insertData)
        {
            toastMessage("Data successfully inserted");
        }
        else
        {
            toastMessage("Something went wrong");
        }
    }
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

