package com.example.lebon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

import static com.example.lebon.MainActivity.addtocart;

public class Addtocart extends AppCompatActivity {

    ListView mlistview2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtocart);

        Button addall = findViewById(R.id.addall);
        mlistview2 = findViewById(R.id.listview2);
        AdapterAddtocart madapter = new AdapterAddtocart(this, R.layout.row2, addtocart);
        mlistview2.setAdapter(madapter);

        mlistview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (view.getId()){
                    case R.id.buynow:
                        Intent i3 = new Intent(Addtocart.this,Buynow.class);
                        i3.putExtra("index", i);
                        startActivity(i3);
                        break;
                }
            }
        });

        addall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(Addtocart.this,Buynow.class);
                i3.putExtra("buy all",1);
                startActivity(i3);
            }
        });

    }
}
