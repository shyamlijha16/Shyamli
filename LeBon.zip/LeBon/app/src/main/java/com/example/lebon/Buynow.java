package com.example.lebon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.example.lebon.MainActivity.addtocart;
import static com.example.lebon.MainActivity.allproducts;

public class Buynow extends AppCompatActivity {

    ListView morderlist;
    public static ArrayList<CakeList> allitems;
    EditText address;
    Button addaddress;
    Button resetaddress;
    TextView addressdisplay;
    TextView totalamount;
    Button placeorder;
    public static String ordereditems = "";
    static SharedPreferences sharedPreferences3;
    String e;
    String[] f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buynow);

        morderlist = findViewById(R.id.orderlist);
        address = findViewById(R.id.address);
        addaddress = findViewById(R.id.addaddress);
        resetaddress = findViewById(R.id.resetaddress);
        addressdisplay = findViewById(R.id.addressdisplay);
        totalamount = findViewById(R.id.totalamount);
        placeorder = findViewById(R.id.placeorder);

        allitems = new ArrayList<>();

        sharedPreferences3 = getSharedPreferences("ordered",MODE_PRIVATE);
        e = sharedPreferences3.getString("ordereditems","");
        f = e.split(",");
        for(int i=0;i<f.length;i++){
            if(f[i].equals("")){
                continue;
            }
            int index = Integer.parseInt(f[i]);
            allitems.add(allproducts.get(index));
        }



        int index = getIntent().getExtras().getInt("index");

        int previousActivity = getIntent().getExtras().getInt("buy all");

        if(previousActivity > 0)
        {
            allitems = (ArrayList<CakeList>)addtocart.clone();
            addtocart.clear();
        }
        else
        {
            allitems.add(allproducts.get(index));
        }

        morderlist = findViewById(R.id.orderlist);
        AdapterBuynow adapt = new AdapterBuynow(this, R.layout.row3,allitems);
        morderlist.setAdapter(adapt);

        addaddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String maddress = address.getText().toString();
                addressdisplay.setText("ADDRESS:\t"+maddress);
            }
        });

        resetaddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                address.setText("");
                addressdisplay.setText("");
                address.requestFocus();
            }
        });

        int i;
        double total = 0.00;
        for(i=0;i<allitems.size();i++)
        {
            total = total + (allitems.get(i).getAmount());
        }

        totalamount.setText("          TOTAL AMOUNT:\t                                     "+total);


        placeorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index3 = 0;
                for(int i=0;i<allproducts.size();i++){
                    if(allitems.get(i).getNameofproducts() == allproducts.get(i).getNameofproducts()){
                        index3 = i;
                        break;
                    }
                }
                ordereditems+= index3+",";
                SharedPreferences.Editor editor = sharedPreferences3.edit();
                editor.putString("ordereditems",ordereditems);
                editor.commit();
                toastMessage("ORDER PLACED");
            }
        });
    }
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
