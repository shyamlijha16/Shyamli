package com.example.lebon;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class AdapterBuynow extends ArrayAdapter<CakeList> {

    Context ocontext;
    int resource3;
    ArrayList<CakeList> nobjects;

    public AdapterBuynow(@NonNull Context context, int resource, @NonNull ArrayList<CakeList> objects) {
        super(context, resource, objects);
        this.ocontext = context;
        this.resource3 = resource;
        this.nobjects = objects;
    }

    @NonNull
    @Override
    public View getView(final int position, @NonNull View convertView, @NonNull ViewGroup parent) {
        LayoutInflater oinflater = LayoutInflater.from(ocontext);

        View oview = oinflater.inflate(resource3, null);
        TextView nameofcakes3 = oview.findViewById(R.id.nameofproducts3);
        TextView amountofcakes3 = oview.findViewById(R.id.amountofproducts3);
        ImageView imagebutton3 = oview.findViewById(R.id.imagebutton3);

        final CakeList cakelist = nobjects.get(position);

        nameofcakes3.setText(cakelist.getNameofproducts());
        amountofcakes3.setText(cakelist.getAmount() + "");
        imagebutton3.setImageDrawable(ocontext.getResources().getDrawable(cakelist.getImage()));

        Button cancelorder = oview.findViewById(R.id.cancelorder);

        cancelorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nobjects.remove(position);
                notifyDataSetChanged();
                toastMessage("ORDER CANCELLED");
            }
        });

        return oview;
    }
    private void toastMessage(String message) {
        Toast.makeText(ocontext, message, Toast.LENGTH_SHORT).show();
    }
}

