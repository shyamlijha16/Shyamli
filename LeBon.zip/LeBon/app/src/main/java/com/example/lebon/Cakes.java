package com.example.lebon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;


public class Cakes extends AppCompatActivity {

    Toolbar mtoolbar;
    List<CakeList> objects;
    ListView mlistview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cakes);

        objects = new ArrayList<>();
        objects.add(new CakeList(R.drawable.blueberry, "BLUEBERRY CAKE", 250));
        objects.add(new CakeList(R.drawable.strawberry, "STRAWBERRY CAKE", 300));
        objects.add(new CakeList(R.drawable.blackforest, "BLACKFOREST CAKE", 400));

        mlistview = findViewById(R.id.listview);
        mlistview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (view.getId()){
                    case R.id.buynow:
                        Intent i3 = new Intent(Cakes.this,Buynow.class);
                        i3.putExtra("index", i);
                        i3.putExtra("buy all",-1);
                        startActivity(i3);
                        break;
                }
            }
        });

        AdapterCakes adapter = new AdapterCakes(this, R.layout.row, objects);
        mlistview.setAdapter(adapter);

        Toolbar mtoolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("CAKES!");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.orders) {
            Intent i2 = new Intent(Cakes.this, Orders.class);
            startActivity(i2);
            return true;
        } else if (id == R.id.favorites) {
            Intent i2 = new Intent(Cakes.this, MyFavourites.class);
            startActivity(i2);
            return true;
        } else if (id == R.id.contact) {
            Intent i2 = new Intent(Cakes.this, Contact.class);
            startActivity(i2);
            return true;
        } else if (id == R.id.feedback) {
            Intent i2 = new Intent(Cakes.this, Feedback.class);
            startActivity(i2);
            return true;
        } else if (id == R.id.basket) {
            Intent i2 = new Intent(Cakes.this, Addtocart.class);
            startActivity(i2);
        }
        return super.onOptionsItemSelected(item);
    }

}
