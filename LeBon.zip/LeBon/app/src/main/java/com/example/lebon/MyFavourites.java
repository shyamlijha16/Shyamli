package com.example.lebon;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import static com.example.lebon.MainActivity.addtocart;
import static com.example.lebon.MainActivity.addtofavourite;

public class MyFavourites extends AppCompatActivity {

    ListView nlistview3;
    Button addall;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_favourites);

        addall = findViewById(R.id.addall);
        nlistview3 = findViewById(R.id.listview3);
        AdapterAddtofavourites nadapter = new AdapterAddtofavourites(this, R.layout.row2, addtofavourite);
        nlistview3.setAdapter(nadapter);

        nlistview3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (view.getId()){
                    case R.id.buynow:
                        Intent i4 = new Intent(MyFavourites.this,Buynow.class);
                        i4.putExtra("index", i);
                        i4.putExtra("buy all",-1);
                        startActivity(i4);
                        break;
                }
            }
        });

        addall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i4 = new Intent(MyFavourites.this,Buynow.class);
                i4.putExtra("buy all",1);
                startActivity(i4);
            }
        });
    }
}
