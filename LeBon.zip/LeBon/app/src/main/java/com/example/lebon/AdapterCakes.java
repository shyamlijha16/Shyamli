package com.example.lebon;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;

import static com.example.lebon.MainActivity.addtocart;
import static com.example.lebon.MainActivity.addtofavourite;
import static com.example.lebon.MainActivity.setAddtocart;
import static com.example.lebon.MainActivity.setAddtofavourites;

public class AdapterCakes extends ArrayAdapter<CakeList> {

    Context mcontext;
    int resource;
    List<CakeList> objects;
    List<CakeList> itemsFull;

    public AdapterCakes(@NonNull Context mcontext, int resource, @NonNull List<CakeList> objects) {
        super(mcontext, resource, objects);
        this.mcontext = mcontext;
        this.resource = resource;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater minflater = LayoutInflater.from(mcontext);

        View mview = minflater.inflate(resource, null);//we can also use R.layout.row instead of resource

        TextView nameofcakes = mview.findViewById(R.id.nameofproducts);
        TextView amountofcakes = mview.findViewById(R.id.amountofproducts);
        ImageView imagebutton = mview.findViewById(R.id.imagebutton);

       final CakeList cakelist = objects.get(position);

       nameofcakes.setText(cakelist.getNameofproducts());
       amountofcakes.setText(cakelist.getAmount()+"");
       imagebutton.setImageDrawable(mcontext.getResources().getDrawable(cakelist.getImage()));

        ImageButton mimagebutton = mview.findViewById(R.id.mimagebutton);
        ImageButton nimagebutton = mview.findViewById(R.id.nimagebutton);
        Button buynow = mview.findViewById(R.id.buynow);

        mimagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAddtofavourites(cakelist);
                toastMessage("ITEM ADDED TO FAVOURITES");
            }
        });

        nimagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAddtocart(cakelist);
                toastMessage("ITEM ADDED TO CART");
            }
        });

        buynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i3 = new Intent(getContext(),Buynow.class);
                i3.putExtra("index",position);
                i3.putExtra("Buy all",-1);
                getContext().startActivity(i3);
            }
        });



        return mview;
    }
    private void toastMessage(String message) {
        Toast.makeText(mcontext, message, Toast.LENGTH_SHORT).show();
    }
}
