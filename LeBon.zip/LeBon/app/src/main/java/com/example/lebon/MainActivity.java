package com.example.lebon;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    
    Toolbar mtoolbar;
    ImageView mcakes;
    ImageView msavory;
    ImageView mflowers;
    TextView mcakes2;
    TextView msavory2;
    TextView mflowers2;
    public static ArrayList<CakeList> addtocart;
    public static ArrayList<CakeList> addtofavourite;
    public static ArrayList<CakeList> allproducts;
    public static ArrayList<String> allproductsname;
    public static String cartitems = "";
    public static String favouriteitems = "";
    static SharedPreferences sharedPreferences;
    static SharedPreferences sharedPreferences2;
    String a;
    String c;
    String[] b;
    String[] d;
    ArrayAdapter<String> arrayadapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar mtoolbar = (Toolbar) findViewById(R.id.toolbar);
        ImageView mcakes = (ImageView)findViewById(R.id.cakes);
        ImageView msavory = (ImageView)findViewById(R.id.savory);
        ImageView mflowers = (ImageView)findViewById(R.id.flowers);
        TextView mcakes2 = (TextView)findViewById(R.id.cakes2);
        TextView msavory2 = (TextView)findViewById(R.id.savory2);
        TextView mflowers2 = (TextView)findViewById(R.id.flowers2);
        addtocart = new ArrayList<>();
        addtofavourite = new ArrayList<>();
        allproducts = new ArrayList<>();
        allproductsname = new ArrayList<>();

        allproductsname.add("BLUEBERRY CAKE");
        allproductsname.add("STRAWBERRY CAKE");
        allproductsname.add("BLACKFOREST CAKE");
        allproductsname.add("AMARYLLIS");
        allproductsname.add("LILLIES");
        allproductsname.add("ROSES");
        allproductsname.add("GINGERBREAD");
        allproductsname.add("PIE");
        allproductsname.add("FRUIT BREAD");


        arrayadapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,allproductsname);


        populateList();
        sharedPreferences = getSharedPreferences("cart",MODE_PRIVATE);
        a = sharedPreferences.getString("cartitems","");
        b = a.split(",");
        for(int i=0;i<b.length;i++){
            if(b[i].equals("")){
                continue;
            }
            int index = Integer.parseInt(b[i]);
            addtocart.add(allproducts.get(index));
        }

        sharedPreferences2 = getSharedPreferences("favourties",MODE_PRIVATE);
        c = sharedPreferences2.getString("favouriteitems","");
        d = c.split(",");
        for(int i=0;i<d.length;i++){
            if(b[i].equals("")){
                continue;
            }
            int index2 = Integer.parseInt(d[i]);
            addtofavourite.add(allproducts.get(index2));
        }


        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("WELCOME!");

        mcakes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Cakes.class);
                startActivity(i);
            }
        });

        msavory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Savory.class);
                startActivity(i);
            }
        });

        mflowers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Flowers.class);
                startActivity(i);
            }
        });

        mcakes2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Cakes.class);
                startActivity(i);
            }
        });

        msavory2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Savory.class);
                startActivity(i);
            }
        });

        mflowers2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Flowers.class);
                startActivity(i);
            }
        });
    }

    public static void setAddtocart(CakeList item){
        addtocart.add(item);
        int index = 0;
        for(int i=0;i<allproducts.size();i++){
            if(item.getNameofproducts() == allproducts.get(i).getNameofproducts()){
                index = i;
                break;
            }
        }
        cartitems+= index+",";
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("cartitems",cartitems);
        editor.commit();
    }

    public static void setAddtofavourites(CakeList item2){
        addtofavourite.add(item2);
        int index2 = 0;
        for(int i =0;i<allproducts.size();i++){
            if(item2.getNameofproducts() == allproducts.get(i).getNameofproducts()){
                index2 = i;
                break;
            }
        }
        favouriteitems+= index2+",";
        SharedPreferences.Editor editor2 = sharedPreferences2.edit();
        editor2.putString("favouriteitems",favouriteitems);
        editor2.commit();
    }

    public void populateList() {
        allproducts.add(new CakeList(R.drawable.blueberry, "BLUEBERRY CAKE", 250));
        allproducts.add(new CakeList(R.drawable.strawberry, "STRAWBERRY CAKE", 300));
        allproducts.add(new CakeList(R.drawable.blackforest, "BLACKFOREST CAKE", 400));
        allproducts.add(new CakeList(R.drawable.amaryllis, "BOUQUET OF AMARYLLIS", 900));
        allproducts.add(new CakeList(R.drawable.lilies, "BOUQUET OF LILIES", 700));
        allproducts.add(new CakeList(R.drawable.roses, "BOUQUET OF ROSES", 500));
        allproducts.add(new CakeList(R.drawable.gingerbread, "GINGERBREAD", 180));
        allproducts.add(new CakeList(R.drawable.pie, "PIE", 250));
        allproducts.add(new CakeList(R.drawable.bread, "FRUIT BREAD", 90));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.orders){
            Intent i2 = new Intent(MainActivity.this,Orders.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.favorites){
            Intent i2 = new Intent(MainActivity.this,MyFavourites.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.contact){
            Intent i2 = new Intent(MainActivity.this,Contact.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.feedback){
            Intent i2 = new Intent(MainActivity.this,Feedback.class);
            startActivity(i2);
            return true;
        }
        else if(id == R.id.basket){
            Intent i2 = new Intent(MainActivity.this,Addtocart.class);
            startActivity(i2);
        }
        return super.onOptionsItemSelected(item);
    }
}

