package com.example.lebon;

public class CakeList {

    int image;
    double amount;

    String nameofproducts;

    public CakeList(int image, String nameofcakes, int amount) {
        this.amount = amount;
        this.image = image;
        this.nameofproducts = nameofcakes;
    }

    public double getAmount() {
        return amount;
    }
    public int getImage() {
        return image;
    }

    public String getNameofproducts() {
        return nameofproducts;
    }
}
